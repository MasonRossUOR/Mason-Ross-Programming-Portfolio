def PlaySound(Text,soundcount):
    from gtts import gTTS
    from playsound import playsound
    import os
    
    myobj = gTTS(text=Text, lang='en', slow=False)
    AudioName = str("Audio" + str(soundcount) + ".mp3")
    myobj.save(AudioName) 
    playsound(AudioName)
    soundcount = int(soundcount)
    soundcount = soundcount + 1
    
    try:
        os.remove(AudioName)
        print(AudioName,"deleted")
    except:
        print("failed to delete",AudioName)

    return(soundcount)
