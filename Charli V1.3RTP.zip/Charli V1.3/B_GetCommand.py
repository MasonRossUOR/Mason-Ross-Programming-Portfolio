def GetCommand():
    import speech_recognition as sr
    import os
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Talk now:")
        Command = r.listen(source)
        Command = (r.recognize_google(Command))
        print("thanks")
    
    try:
        # using google speech recognition
        print("You said: ",Command)
    except:
         print("Sorry, I did not get that")

    return(Command)
