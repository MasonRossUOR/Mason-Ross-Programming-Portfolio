import time
import os
from B_OpenProgram import OpenPrograms
from B_SendEmailsCHL import SendEmails
from B_BreakingDownCommands import BreakDownCommand
from B_InterpretingCommands import InterperateCommand
from B_PlaySound import PlaySound
from B_GetCommand import GetCommand
from B_CharliStandby import CharliStandby
Continue = True
soundcount = 0
end = False

def Main(Continue,soundcount,end):
    while True:
        Command = CharliStandby()
        if Command == "hey charlie":
            break
    
    Text = 'How can I help you?'
    soundcount = PlaySound(Text,soundcount)
    Command = GetCommand()
    Command = Command.lower()
    
    while True:
        CommandList = BreakDownCommand(Command)
        soundcount = InterperateCommand(soundcount,CommandList)
        
        if Command == "send email":
            soundcount = SendEmails(soundcount)
        if Command == "open program":
            soundcount = OpenPrograms(soundcount)

        Text = "Anything else?"
        soundcount = PlaySound(Text,soundcount)
        Command = GetCommand()
        Command = Command.lower()
        
        if Command == "goodnight" or Command == "go to sleep":
            end = True
            Continue = False
            break
        
        elif Command == "no":
            Text = 'i am here if you need me'
            soundcount = PlaySound(Text,soundcount)
            break
        
    if Continue == False:
        Text = 'Goodbye for now'
        soundcount = PlaySound(Text,soundcount)
    return(end,soundcount)
        
while end == False:
    end,soundcount = Main(Continue,soundcount,end)


