def ShutDown(soundcount):
    import os
    from B_PlaySound import PlaySound
    from B_GetCommand import GetCommand

    Text = "are you sure?"
    soundcount = PlaySound(Text,soundcount)
    
    while True:
        Command = GetCommand()
        if Command == 'no': 
            break
            Text = "are you sure?"
            soundcount = PlaySound(Text,soundcount)
            
        elif Command == "yes":
            Text = "Shutting down computer"
            soundcount = PlaySound(Text,soundcount)
            os.system("shutdown /s /t 1")
            
        elif Command != 'no' and Command != 'yes':
            Text = "sorry i did not get that"
            soundcount = PlaySound(Text,soundcount)
    return(soundcount)

