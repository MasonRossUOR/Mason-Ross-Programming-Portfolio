
def OpenPrograms(soundcount,Object):
    import subprocess
    import time
    from B_GetCommand import GetCommand
    from B_PlaySound import PlaySound

    def ExecuteOpen(Programs,Locations,Command):
        IndexNo = Programs.index(Command)
        subprocess.Popen(Locations[IndexNo])
        

    def Main(soundcount,Object):
        '''
        Programs = [" notepad"," calculator"," minecraft"," chrome", " google"," spotify"," citra"]
        Locations = ['C:\\Windows\\System32\\notepad.exe','C:\\Windows\\System32\\calc.exe',
                     'C:\Program Files (x86)\Minecraft Launcher\MinecraftLauncher.exe',
                     'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
                     'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
                     'C:\Program Files (x86)\Spotify\Spotify.exe',
                     'C:\Program Files (x86)\Citra\nightly-mingw\citra-qt.exe']

        time.sleep(2)
        if Object not in Programs:
            Text = "What program do you want to open?"
            print(soundcount)
            soundcount = PlaySound(Text,soundcount)
            
            Command = GetCommand()
            Command = Command.lower()
            
        elif Object in Programs:
            Command = Object
            ExecuteOpen(Programs,Locations,Command)
            

        if Command not in Programs:
            Text = str("i couldnt find" + Command)
            print(soundcount)
            soundcount = PlaySound(Text,soundcount)
        return(soundcount)
        '''
    
    soundcount = Main(soundcount,Object)
    return(soundcount)




