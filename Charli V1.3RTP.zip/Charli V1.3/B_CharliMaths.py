
def Maths(CommandList,soundcount):
    print(CommandList)
    from B_PlaySound import PlaySound
    SumList = []
    Operators = [" +"," -","/"," x"]
    SPACE = " "

    def minus(nums):
        Answer = (nums[0] - nums[1])
        return Answer

    def plus(nums):
        Answer = (nums[0] + nums[1])
        return Answer

    def times(nums):
        Answer = (nums[0] * nums[1])
        Answer = round(Answer,3)
        return Answer


    def ProcessCommand(CommandList,SumList):
        for i in range(len(CommandList)):
            if CommandList[i] in Operators:
                MathSign = CommandList[i]
                
                num1 = CommandList[i-1]
                num1 = int(num1)
                num2 = CommandList[i+1]
                num2 = int(num2)
                
                nums = [num1,num2]
                Answer = DirectSum(MathSign,nums)
                break
        return(Answer)
        

    def DirectSum(MathSign,nums):
        if MathSign == " -":
            Answer = minus(nums)
        elif MathSign == " +":
            Answer = plus(nums)
        elif MathSign == " x":
            Answer = times(nums)
        return(Answer)
    
    Answer = ProcessCommand(CommandList,SumList)
    Answer = str(Answer)
    ToBeText = str("The Answer is"+Answer)
    Text = ToBeText
    soundcount = PlaySound(Text,soundcount)
    return(soundcount)

