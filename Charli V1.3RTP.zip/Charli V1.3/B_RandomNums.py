def RandomNums(soundcount,CommandList):
    import random
    from random import randint
    from B_PlaySound import PlaySound

    def GetNums(CommandList):
        if " and" in CommandList:
            Marker = CommandList.index(" and")
            
            num1 = CommandList[Marker-1]
            num1 = int(num1)
            num2 = CommandList[Marker+1]
            num2 = int(num2)
        else:
            print("failed to get numbers")
        return(num1,num2)

    def GenRandomNum(num1,num2):
        RandNum = randint(num1,num2)
        return(RandNum)

    num1,num2 = GetNums(CommandList)
    RandNum = GenRandomNum(num1,num2)
    Text = str(RandNum)
    soundcount = PlaySound(Text,soundcount)
    return(soundcount)
