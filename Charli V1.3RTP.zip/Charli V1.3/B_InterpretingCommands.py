def InterperateCommand(soundcount,CommandList):
    from B_OpenProgram import OpenPrograms
    from B_SendEmailsCHL import SendEmails
    from B_ShutDown import ShutDown
    from B_CharliMaths import Maths
    from B_RandomNums import RandomNums

    
    AvaliableCommands = [" open"," send"," shut"," work"," generate"]

    def CheckForCommand(soundcount,CommandList):
        for i in range(len(CommandList)):
            if CommandList[i] in AvaliableCommands:
                Command = CommandList[i]
                Object = CommandList [i+1]
                Command = Command.lower()
                Object = Object.lower()
                
                soundcount = ExecuteCommand(soundcount,Command,Object,CommandList)
        return soundcount

    def ExecuteCommand(soundcount,Command,Object,CommandList):
        while True:
            if Command == " send":
                soundcount = SendEmails(soundcount)
                break
                
            elif Command == " open":
                soundcount = OpenPrograms(soundcount,Object)
                break
            
            elif Command == " shut":
                soundcount = ShutDown(soundcount)
                break

            elif Command == " work":
                soundcount = Maths(CommandList,soundcount)
                break
            elif Command == " generate":
                soundcount = RandomNums(soundcount,CommandList)
                break
    
        return soundcount
            


    soundcount = CheckForCommand(soundcount,CommandList)
    return soundcount

