def BreakDownCommand(Command):
    SPACE = " "
    END = "/"

    def ProcessCommand(Command):
        CommandList = []
        WordCount = 0
        x = 1
        Command = str(SPACE+Command)
        Command = str(Command + END)
        
        for i in range(len(Command)):
            if Command[i] == SPACE:
                while True:
                    print("pass",i)
                    if (Command[i+x] == SPACE)or(Command[i+x] == END):
                        Word = Command[i:i+x]
                        CommandList.insert(WordCount,Word)
                        WordCount = WordCount + 1
                        break
                    else:
                        x = x+1
            x = 1

        return(CommandList)

    CommandList = ProcessCommand(Command)
    return(CommandList)

