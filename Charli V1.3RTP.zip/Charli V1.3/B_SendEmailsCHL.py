def SendEmails(soundcount):
    import time
    import smtplib
    from B_PlaySound import PlaySound
    from B_GetCommand import GetCommand
    SPACE = " "
    rec_e_List = []

    def FixDot(rec_e_List):
        #identify and fix the word 'dot'
        for i in range(len(rec_e_List)):
            if len(rec_e_List) != (i+4):
                if rec_e_List[i] == SPACE and rec_e_List[i+1] == "d":
                    if rec_e_List[i+2] == "o" and rec_e_List[i+3] == "t":
                        if rec_e_List[i+4] == SPACE:
                            rec_e_List.insert(i,".")
                            rec_e_List.pop(i+1)
                            rec_e_List.pop(i+1)
                            rec_e_List.pop(i+1)
                            rec_e_List.pop(i+1)
            else:
                break
        return(rec_e_List)

    def FixAt(rec_e_List):
        for i in range(len(rec_e_List)):
            if len(rec_e_List) >= (i+3):
                if rec_e_List[i] == SPACE and rec_e_List[i+1] == "a":
                    if rec_e_List[i+2] == "t" and rec_e_List[i+3] == SPACE:
                        rec_e_List.insert(i,"@")
                        rec_e_List.pop(i+1)
                        rec_e_List.pop(i+1)
                        rec_e_List.pop(i+1)
                        
        return(rec_e_List)

    def NoSpace(rec_e_List):
        for i in range(len(rec_e_List)):
            if rec_e_List[i] == SPACE:
                rec_e_List.pop(i)
        return(rec_e_List)

    def GetRecEmail(rec_email,rec_e_List):
        if rec_email == "myself": #you need to fix dot and @
            rec_email = ""#redacted for privacy reasons
            
        for i in range(len(rec_email)):
            rec_e_List.insert(i,rec_email[i])

        rec_e_List = FixDot(rec_e_List)
        rec_e_List = FixAt(rec_e_List)
        rec_e_List = NoSpace(rec_e_List)
        rec_email = "".join(map(str, rec_e_List))
        
        return(rec_email)


    def sendEmail(Message,rec_email):
        sender_email = "" #redacted for privacy reasons
        password = ""

        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.ehlo
        server.starttls()
        server.login(sender_email, password)
        print("Login success")
        server.sendmail(sender_email, rec_email, Message)
        print("email sent")

    def Main(rec_e_List,soundcount):
        
        Text = "send to who?"
        soundcount = PlaySound(Text,soundcount)
        rec_email = GetCommand()
        rec_email = GetRecEmail(rec_email,rec_e_List)
        
        time.sleep(2)
        Text = "what would you like to say?"
        soundcount = PlaySound(Text,soundcount)
        Message = GetCommand()

        Text = "sending"
        soundcount = PlaySound(Text,soundcount)
        sendEmail(Message,rec_email)
        Text = "sent successfully"
        soundcount = PlaySound(Text,soundcount)
        time.sleep(2)
        return(soundcount)
    
    soundcount = Main(rec_e_List,soundcount)
    return(soundcount)
