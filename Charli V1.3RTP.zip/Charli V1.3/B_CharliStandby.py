def CharliStandby():
    import speech_recognition as sr
    import os
    import time

    Command = "x"
    r = sr.Recognizer()
    def SetCommand(Command):
        
        if Command != "hey charlie":
            try:
                with sr.Microphone() as source:
                    print("Talk now:")
                    Command = r.listen(source)
                    Command = (r.recognize_google(Command))
                    Command = Command.lower()
            except:
                x = 0
        return(Command)


    Command = SetCommand(Command)
    return(Command)
