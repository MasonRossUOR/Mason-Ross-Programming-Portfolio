#include <stdio.h>
#include <dirent.h>


//This code is pretty much an ls -al

int main(int argc, char *argv[]){
	struct dirent *pDirent;
	DIR *pDir;

	if(argc != 2){ //checks if argument count correct (filename, directory)
		printf("usage:testprog <name>\n");
		return 1;
	}

	pDir = opendir (argv[1]);
	if (pDir == NULL){	//if the directory name isnt there, or if,
				//permission is not granted
		printf("Cannot open directory \n");
		return 1;
		}

	while((pDirent = readdir(pDir))!= NULL){ //prints each file in the directory
		printf("[%s]\n",pDirent->d_name);
		}

	closedir(pDir);
	return 0; //close ddirectory and exit
}
