#include <stdio.h>

int main(int argc, char* argv[]){
	FILE* ptr;

	if (argc-1 != 2){
		printf("incorrect number of parameters\n");
		return 1;
		}
	ptr = fopen(argv[1],"r");
	if (ptr == NULL){
		printf("error, file not found\n");
		return 1;
		}

	int result = rename(argv[1],argv[2]);
	printf("file renamed\n");
	return 0;
}
