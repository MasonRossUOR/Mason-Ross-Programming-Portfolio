#include <stddef.h>
#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[]){
	if (argc-1 == NULL){
		printf("error, no arguments detected\n");
		return 1;
		}

	else if (argc-1 > 1){
		printf("error, too many arguements detected\n");
		return 1;
		}

	if (access(argv[1],F_OK)!= 0){
		printf("error, file not found\n");
		}

	remove(argv[1]);
	printf("File removed\n");
	return 0;
}
