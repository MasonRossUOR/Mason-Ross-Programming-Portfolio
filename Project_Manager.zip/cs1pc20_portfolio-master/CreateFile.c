#include <stdio.h>
#include <stdlib.h>


int main(int argc, char* argv[]){
	int i = 1;
	int UsefulArgc = (argc -1);

	if(UsefulArgc==0){//if no args given, abort
		printf("Error, no arguement detected\n");
		return 0;
		}
	else if(UsefulArgc==1){//if one detected, print out
		printf("%s\n",argv[1]);
		return 1;
		}

	else if(UsefulArgc==2){//if two created, print message x in file y,
				//creating new file if needed
		FILE *fptr;
		char* FileName = argv[1];
		char* Message = argv[2];
		printf("test1");
		fptr = fopen(FileName,"w");
		fprintf(fptr,"%s",Message);
		fclose(fptr);
		return 1;
		}

	else if(UsefulArgc > 2){
		printf("error, too many arguements, expected either 1 or 2, recieved %d\n",UsefulArgc);
		}
}
