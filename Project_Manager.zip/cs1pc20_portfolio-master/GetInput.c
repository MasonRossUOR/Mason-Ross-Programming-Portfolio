#include <string.h>
#include <stdlib.h>
#include <stdio.h>

char Func1(){
	printf("func1 activated\n");
}

char Func2(){
	printf("func2 activated\n");
}

char Func3(){
	printf("func3 activated\n");
}

char CheckCommand(char* Command){
	char* Command_Array[] = {"Make_File","Delete_File","Move"};
	char* Command_Breakdown[] ={"X1","X2","X3","X4","X5"};
	char* token = strtok(Command," ");
	int i = 0;

	while(token != NULL){
		printf("Counter is %d Token is %s\n",i,token);
		Command_Breakdown[i] = token;
		i += 1;
		printf("token is now %s\n",token);
		token = strtok(NULL," ");
		}
	printf("%s\n",Command_Breakdown[1]);

	i = 0;
	/*
	for (i+1; i<(sizeof(Command_Array)+1); ++i){
		if ((strcmp(Command_Breakdown[1],Command_Array[i]))==0){
			printf("works so far\n");

		}
	}*/
}

int main(void){ //forgor this. by using the paramter handing in you can go
		//./pm Makefile thisfile as pm (x,y) no need to break apart the string
	char Command[75];
	char* Function_Array[] = {Func1,Func2,Func3};
	char* Command_Array[] = {"Make_File","Delete_File","Move"};
	while(1){
		printf("£");
		sscanf("%s",&Command);
		printf("command is %s at start\n",Command);

		int result;
		result = strcmp(Command,"pm");
		if (result == 0){
			printf("Command is %s when handed into CheckCommand",Command);
			//char Result = CheckCommand(Command);
			}
		else{
			printf("else triggered");
			return 0;
			}
		}
}

