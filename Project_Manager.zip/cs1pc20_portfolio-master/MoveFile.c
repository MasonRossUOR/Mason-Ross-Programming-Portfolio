#include <stdio.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/stat.h>
#include <string.h>

int main(int argc, char *argv[]){
	char Command[50] = "mv ";
	int status;

	if (argc-1 != 2){
		printf("error occoured, incorrect number of arguments\n");
		return 1;
		}
	if(mkdir(argv[2],0777)==-1){
		strcat(Command,argv[1]);
		strcat(Command," ");
		strcat(Command,argv[2]);
		status = system(Command);
		printf("File Moved\n");
		return 0;
		}
	printf("error, directory not found\n");
	return 1;
}
