#include <stdio.h>
#include <dirent.h>
#include <stdlib.h>

int main(int argc, char* argv[]){
	struct dirent *pDirent;

	char* FileName = ".pm_tag";
	char* TagName = argv[1];

	FILE *fptr;
	DIR *pDir;

	if (argc != 2){
		printf("error, incorrect number of arguements\n");
		return 1;
		}

	pDir = opendir(".");

	while((pDirent = readdir(pDir))!=NULL){
		if (strcmp(pDirent->d_name,".pm_tag")==0){
			printf("error, tag already found\n");
			return 1;
			}
		}

	fptr = fopen(FileName,"w");
	fprintf(fptr,"%s",TagName);
	fclose(fptr);
	printf("Tag created\n");
	return 0;
}

