#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]){
	int status;
	int i;
	char Command[50] = "./";

	for(i=1; i<argc;++i){
		strcat(Command,argv[i]);
		strcat(Command," ");//concatenates
		}

	status = system(Command);//executes the command
	return 0;

}
