#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>

//This code creates new directories
//it can take either one or two parameters, the first being
//the desired name for the directory, and the second (if present) tells
//the program to open a git repository

int main(int argc, char *argv[]){
	if (argv[2]!=NULL){//checks for two parameters
		if (strcmp(argv[2],"git")== 0){
			int status;
			char Command[50] ="git init ";
			strcat(Command, argv[1]); //preps the command

			status = system(Command);//makes git
			return 0;
			}

		printf("error, unrecognised parameters\n");//second parameter was present but
		return 1;				  //not "git"
		}

	if (mkdir(argv[1],0777)==-1){ //mkdir will return -1 if it fails
		printf("Error while creating directory\n");
		perror("Error Type"); //gets exact error
		return 1;
		}
	printf("directory created\n");
	return 0;
}
