#include <stdio.h>
#include <dirent.h>

//this code runs a search of the current directory and looks for the desired
//tag, if it cannot be found for various reasons the code returns, otherwise it prints the
//file path of the tag file

int main(int argc, char* argv[]){
	struct dirent *pDirent;
	DIR *pDir;
	FILE *ptr;
	char* FileContent[1000];

	pDir = opendir(".");
	while((pDirent= readdir(pDir))!=NULL){
		if (strcmp(pDirent->d_name,".pm_tag")==0){
			printf("tag found\n");//a file named .pm_tag found
			ptr = fopen(".pm_tag","r");

			if (ptr == NULL){
				return 1;//tag empty or non existent
				}

			while(fscanf(ptr,"%s",FileContent)!=EOF){
				printf("%s\n",FileContent);//scans the file and gets a string
				}
			fclose(ptr);

			if (strcmp(argv[1],FileContent)==0){
				printf("tag found\n");
				char *path = realpath(ptr,NULL);
				printf("path[%s]\n",path);
				return 0;
				}
			return 0;
			}
		}
	printf("tag not found\n");
}
